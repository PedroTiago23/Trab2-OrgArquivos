#ifndef CREATETABLE
#define CREATETABLE 

#include "Estruturas.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

void lerIntCSV(int* campoRegistro, char** separationPtr);

void LerRegistroCSV(char *linha, REGISTRO *reg);

void CREATE_TABLE();



#endif