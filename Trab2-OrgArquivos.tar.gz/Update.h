#ifndef UPDATE 
#define UPDATE 

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include "Estruturas.h"

void UPDATE();

#endif 