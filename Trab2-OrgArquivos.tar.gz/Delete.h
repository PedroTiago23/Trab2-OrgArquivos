#ifndef DELETE
#define DELETE

#include <stdio.h>
#include "Estruturas.h"

void DELETE();



#endif 