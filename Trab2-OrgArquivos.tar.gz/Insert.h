#ifndef INSERT 
#define INSERT 

#include <stdio.h>
#include <stdlib.h>
#include "Estruturas.h"

void lerRegistroTerminal(REGISTRO* novoRegistro);

void INSERT();

#endif 