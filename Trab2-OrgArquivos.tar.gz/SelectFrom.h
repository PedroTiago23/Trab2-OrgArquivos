#ifndef SELECTFROM 
#define SELECTFROM 

#include <stdio.h>
#include <stdlib.h>
#include "Estruturas.h"
#include <stdbool.h>


void SELECT();

#endif 