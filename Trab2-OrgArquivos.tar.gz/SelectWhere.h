#ifndef SELECTWHERE 
#define SELECTWHERE 

#include <stdio.h>
#include <stdbool.h>
#include "Estruturas.h"


void SELECT_WHERE();

#endif 